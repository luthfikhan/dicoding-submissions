import * as dotenv from 'dotenv'
dotenv.config()

import Hapi from '@hapi/hapi'
import album from './src/api/album/index.js';
import AlbumPostgresService from './src/service/postgres/album.js';
import Joi from 'joi';
import song from './src/api/song/index.js';
import SongPostgresService from './src/service/postgres/song.js';

const init = async () => {

  Joi.ValidationError = undefined

    const server = Hapi.server({
        port: 5000,
        host: 'localhost',
        debug: {
            request: ['*']
        }
    });
    server.validator(Joi);

    await server.start();

    server.ext('onPreResponse', async (request, h) => {
      const response = request.response;
      const statusCode = response.statusCode || response.output.statusCode;

      if (response.isBoom) {
        const { statusCode, payload } = response.output;
        const { message } = payload;

        return h.response({
          status: [400, 404].includes(statusCode) ? 'fail' : 'error',
          message,
        }).code(statusCode);
      } else {
        if ([404, 400, 500].includes(statusCode)) {
          return h.response({
            status: statusCode === 500 ? 'error' : 'fail',
            message: response.source.message,
          }).code(statusCode);
        }
      }

      return h.continue;
    })

    const songPostgres = new SongPostgresService()

    server.register({
      plugin: album,
      options: {
        albumPostgres: new AlbumPostgresService(),
        songPostgres,
      }
    });
    server.register({
      plugin: song,
      options: {
        service: songPostgres
      }
    })

    console.log('Server running on %s', server.info.uri);
};

process.on('unhandledRejection', (err) => {
    console.log(err);
    process.exit(1);
});

init();