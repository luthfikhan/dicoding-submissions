import { nanoid } from "nanoid";

class AlbumHandler {
  constructor(service, songPostgres) {
    this._service = service
    this._songPostgres = songPostgres

    this.postAlbumHandler = this.postAlbumHandler.bind(this);
    this.getAlbumsHandler = this.getAlbumsHandler.bind(this);
    this.getAlbumByIdHandler = this.getAlbumByIdHandler.bind(this);
    this.putAlbumByIdHandler = this.putAlbumByIdHandler.bind(this);
    this.deleteAlbumByIdHandler = this.deleteAlbumByIdHandler.bind(this);
  }

  async postAlbumHandler(request, h) {
    const { name, year } = request.payload;
    const id = nanoid(16);

    const albumId = await this._service.addAlbum({ name, year, id: `album-${id}` });

    const response = h.response({
      status: 'success',
      message: 'Album berhasil ditambahkan',
      data: {
        albumId,
      },
    });
    response.code(201);
    return response;
  }

  async getAlbumsHandler() {
    const albums = await this._service.getAlbums();
    return {
      status: 'success',
      data: {
        albums,
      },
    };
  }

  async getAlbumByIdHandler(request, h) {
    const { id } = request.params;
    const album = await this._service.getAlbumById(id);
    const songs = await this._songPostgres.getSongByAlbumId(id)
    
    if (album.length === 0) {
      return h.response({
        message: 'Album tidak ditemukan',
      }).code(404);
    }

    return {
      status: 'success',
      data: {
        album: {
          ...album[0],
          songs,
        },
      },
    };
  }

  async putAlbumByIdHandler(request, h) {
    const { id } = request.params;

    const album = await this._service.editAlbumById(id, request.payload);

    if (album.length === 0) {
      return h.response({
        message: 'Album tidak ditemukan',
      }).code(404);
    }

    return {
      status: 'success',
      message: 'Album berhasil diperbarui',
    };
  }

  async deleteAlbumByIdHandler(request, h) {
    const { id } = request.params;
    const album = await this._service.deleteAlbumById(id);

    if (album.length === 0) {
      return h.response({
        message: 'Album tidak ditemukan',
      }).code(404);
    }

    return {
      status: 'success',
      message: 'Album berhasil dihapus',
    };
  }
}

export default AlbumHandler;
