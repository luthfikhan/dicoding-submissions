import Joi from "joi"

const albumScheme = Joi.object({
  name: Joi.string().required(),
  year: Joi.number().integer().min(1970).max(2022).required(),
})

export default (handler) => [
  {
    method: 'POST',
    path: '/albums',
    handler: handler.postAlbumHandler,
    options: {
      validate: {
        payload: albumScheme
      }
    }
  },
  {
    method: 'GET',
    path: '/albums',
    handler: handler.getAlbumsHandler,
  },
  {
    method: 'GET',
    path: '/albums/{id}',
    handler: handler.getAlbumByIdHandler,
  },
  {
    method: 'PUT',
    path: '/albums/{id}',
    handler: handler.putAlbumByIdHandler,
    options: {
      validate: {
        payload: albumScheme
      }
    }
  },
  {
    method: 'DELETE',
    path: '/albums/{id}',
    handler: handler.deleteAlbumByIdHandler,
  }
]