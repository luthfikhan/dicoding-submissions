import Joi from "joi"

const songScheme = Joi.object({
  title: Joi.string().required(),
  year: Joi.number().integer().min(1970).max(2022).required(),
  performer: Joi.string().required(),
  genre: Joi.string().required(),
  duration: Joi.number().integer().min(1),
  albumId: Joi.string(),
})

export default (handler) => [
  {
    method: 'POST',
    path: '/songs',
    handler: handler.postSongHandler,
    options: {
      validate: {
        payload: songScheme
      }
    }
  },
  {
    method: 'GET',
    path: '/songs',
    handler: handler.getSongHandler,
  },
  {
    method: 'GET',
    path: '/songs/{id}',
    handler: handler.getSongByIdHandler,
  },
  {
    method: 'PUT',
    path: '/songs/{id}',
    handler: handler.putSongByIdHandler,
    options: {
      validate: {
        payload: songScheme
      }
    }
  },
  {
    method: 'DELETE',
    path: '/songs/{id}',
    handler: handler.deleteSongByIdHandler,
  }
]