import { nanoid } from "nanoid";

class SongHandler {
  constructor(service) {
    this._service = service;

    this.postSongHandler = this.postSongHandler.bind(this);
    this.getSongHandler = this.getSongHandler.bind(this);
    this.getSongByIdHandler = this.getSongByIdHandler.bind(this);
    this.putSongByIdHandler = this.putSongByIdHandler.bind(this);
    this.deleteSongByIdHandler = this.deleteSongByIdHandler.bind(this);
  }

  async postSongHandler(request, h) {
    const id = nanoid(16);

    const songId = await this._service.addSong({ ...request.payload, id: `song-${id}` });

    const response = h.response({
      status: 'success',
      message: 'Musik berhasil ditambahkan',
      data: {
        songId,
      },
    });
    response.code(201);
    return response;
  }

  async getSongHandler(request) {
    const songs = await this._service.getSongs(request.query);
    return {
      status: 'success',
      data: {
        songs,
      },
    };
  }

  async getSongByIdHandler(request, h) {
    const { id } = request.params;
    const song = await this._service.getSongById(id);
    
    if (song.length === 0) {
      return h.response({
        message: 'Musik tidak ditemukan',
      }).code(404);
    }

    return {
      status: 'success',
      data: {
        song: song[0],
      },
    };
  }

  async putSongByIdHandler(request, h) {
    const { id } = request.params;

    const song = await this._service.editSongById(id, request.payload);

    if (song.length === 0) {
      return h.response({
        message: 'Musik tidak ditemukan',
      }).code(404);
    }

    return {
      status: 'success',
      message: 'Musik berhasil diperbarui',
    };
  }

  async deleteSongByIdHandler(request, h) {
    const { id } = request.params;
    const song = await this._service.deleteSongById(id);

    if (song.length === 0) {
      return h.response({
        message: 'Musik tidak ditemukan',
      }).code(404);
    }

    return {
      status: 'success',
      message: 'Musik berhasil dihapus',
    };
  }
}

export default SongHandler;
