import { nanoid } from "nanoid";
import { postAlbumValidator, putAlbumValidator } from "./validator.js";

class AlbumHandler {
  constructor(service, songPostgres) {
    this._service = service;
    this._songPostgres = songPostgres;

    this.postAlbumHandler = this.postAlbumHandler.bind(this);
    this.getAlbumsHandler = this.getAlbumsHandler.bind(this);
    this.getAlbumByIdHandler = this.getAlbumByIdHandler.bind(this);
    this.putAlbumByIdHandler = this.putAlbumByIdHandler.bind(this);
    this.deleteAlbumByIdHandler = this.deleteAlbumByIdHandler.bind(this);
  }

  async postAlbumHandler(request, h) {
    postAlbumValidator(request.payload);
    const { name, year } = request.payload;
    const id = nanoid(16);

    const albumId = await this._service.addAlbum({
      name,
      year,
      id: `album-${id}`,
    });

    return h
      .response({
        status: "success",
        message: "Album berhasil ditambahkan",
        data: {
          albumId,
        },
      })
      .code(201);
  }

  async getAlbumsHandler() {
    const albums = await this._service.getAlbums();
    return {
      status: "success",
      data: {
        albums,
      },
    };
  }

  async getAlbumByIdHandler(request) {
    const { id } = request.params;
    const album = await this._service.getAlbumById(id);
    const songs = await this._songPostgres.getSongByAlbumId(id);

    return {
      status: "success",
      data: {
        album: {
          ...album[0],
          songs,
        },
      },
    };
  }

  async putAlbumByIdHandler(request) {
    putAlbumValidator(request.payload);
    const { id } = request.params;

    await this._service.editAlbumById(id, request.payload);

    return {
      status: "success",
      message: "Album berhasil diperbarui",
    };
  }

  async deleteAlbumByIdHandler(request) {
    const { id } = request.params;
    await this._service.deleteAlbumById(id);

    return {
      status: "success",
      message: "Album berhasil dihapus",
    };
  }
}

export default AlbumHandler;
