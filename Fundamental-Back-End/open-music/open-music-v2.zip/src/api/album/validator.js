import Joi from "joi";
import { BadRequestException } from "../../utils/exception.js";

const albumScheme = Joi.object({
  name: Joi.string().required(),
  year: Joi.number().integer().min(1970).max(2022).required(),
});

export const postAlbumValidator = (data) => {
  const { error } = albumScheme.validate(data);

  if (error) {
    throw new BadRequestException(error.message);
  }
};

export const putAlbumValidator = (data) => {
  const { error } = albumScheme.validate(data);

  if (error) {
    throw new BadRequestException(error.message);
  }
};
