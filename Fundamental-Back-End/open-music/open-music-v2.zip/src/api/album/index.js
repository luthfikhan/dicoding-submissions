import routes from './routes.js';
import Handler from './handler.js';

export default {
  name: 'album',
  version: '1.0.0',
  register: async (server, { albumPostgres, songPostgres }) => {
    const albumHandler = new Handler(albumPostgres, songPostgres);

    server.route(routes(albumHandler))
  }
}