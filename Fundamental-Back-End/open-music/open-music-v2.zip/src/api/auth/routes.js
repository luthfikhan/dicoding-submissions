export default (handler) => [
  {
    method: "POST",
    path: "/users",
    handler: handler.postUserHandler,
  },
  {
    method: "POST",
    path: "/authentications",
    handler: handler.postAuthenticationsHandler,
  },
  {
    method: "PUT",
    path: "/authentications",
    handler: handler.putAuthenticationsHandler,
  },
  {
    method: "DELETE",
    path: "/authentications",
    handler: handler.deleteAuthenticationsHandler,
  },
];
