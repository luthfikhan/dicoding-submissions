package id.filab.storyapp.dto

data class RegisterPayload(
    var name: String = "",
    var email: String = "",
    var password: String = "",
)
