package id.filab.storyapp.viewmodel

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import id.filab.storyapp.R
import id.filab.storyapp.dto.LoginPayload
import id.filab.storyapp.dto.LoginResponse
import id.filab.storyapp.dto.RegisterPayload
import id.filab.storyapp.dto.RegisterResponse
import id.filab.storyapp.services.getApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserViewModel: ViewModel() {
    var token by mutableStateOf("")

    companion object {
        val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user")
        val TOKEN_KEY = stringPreferencesKey("token")
    }

    fun getToken(context: Context): Flow<String?> {
        val t = context.dataStore.data.map {
            it[TOKEN_KEY]
        }
        return t
    }
    suspend fun saveToken(t: String, context: Context) {
        token = t
        context.dataStore.edit {
            it[TOKEN_KEY] = t
        }
    }
    suspend fun deleteToken(context: Context) {
        token = ""
        context.dataStore.edit {
            it.remove(TOKEN_KEY)
        }
    }

    fun submitRegister (registerPayload: RegisterPayload, context: Context, callback: (done: Boolean) -> Unit)  {
        val api = getApiService().register(registerPayload)

        api.enqueue(object: Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                val error = response.body()?.error ?: false
                if (response.isSuccessful && !error) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.signup_success_text),
                        Toast.LENGTH_LONG
                    ).show()
                    callback(true)
                } else {
                    Toast.makeText(
                        context,
                        context.getString(R.string.signup_failed_text),
                        Toast.LENGTH_LONG
                    ).show()
                    callback(true)
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                Toast.makeText(context, context.getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show()
                callback(true)
            }

        })
    }

    fun submitLogin (loginPayload: LoginPayload, context: Context, callback: (success: Boolean) -> Unit)  {
        val api = getApiService().login(loginPayload)

        api.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                val error = response.body()?.error ?: false
                if (response.isSuccessful && !error) {
                    val body = response.body()

                    viewModelScope.launch {
                        saveToken(body?.loginResult?.token ?: "", context)
                    }
                    callback(true)
                } else {
                    callback(false)
                    Toast.makeText(
                        context,
                        context.getString(R.string.login_failed_text),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                Toast.makeText(context, context.getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show()
                callback(false)
            }

        })
    }
}