package id.filab.storyapp.ui.screen

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import id.filab.storyapp.R
import id.filab.storyapp.ui.navigation.Routes
import id.filab.storyapp.viewmodel.StoryViewModel
import id.filab.storyapp.viewmodel.UserViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StoriesScreen(
    userViewModel: UserViewModel,
    storyViewModel: StoryViewModel,
    navigateTo: (route: String) -> Unit
) {
    var showLoader by remember { mutableStateOf(false) }
    var showMenus by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    if (showLoader) {
        Dialog(onDismissRequest = {}) {
            CircularProgressIndicator()
        }
    }

    LaunchedEffect(Unit) {
        showLoader = true
        storyViewModel.getStories(userViewModel.token, context) {
            showLoader = false
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navigateTo(Routes.StoryPickerScreen.route) },
                backgroundColor = MaterialTheme.colors.primary
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = stringResource(R.string.content_desc_add_new_story_fab)
                )
            }
        },

        topBar = {
            TopAppBar(
                title = {
                    Text(text = stringResource(id = R.string.app_name))
                },
                actions = {
                    IconButton(onClick = { showMenus = !showMenus }) {
                        Icon(Icons.Default.MoreVert, "")
                    }
                    DropdownMenu(expanded = showMenus, onDismissRequest = { showMenus = false }) {
                        DropdownMenuItem(
                            onClick = {
                                coroutineScope.launch {
                                    userViewModel.deleteToken(context)
                                }
                                navigateTo(Routes.SignupScreen.route)
                            }
                        ) {
                            Text(text = stringResource(R.string.menu_logout_text))
                        }
                    }
                }
            )
        }
    ) {
        LazyColumn(
            content = {
                itemsIndexed(storyViewModel.stories.listStory) { index, item ->
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .shadow(elevation = 10.dp, shape = RoundedCornerShape(12.dp))
                            .background(color = Color.White)
                            .clickable {
                                navigateTo(Routes.StoryDetailScreen.withArgs(index.toString()))
                            }
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(item.photoUrl)
                                .crossfade(true)
                                .build(),
                            contentScale = ContentScale.Crop,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .clip(shape = RoundedCornerShape(12.dp))
                                .height(460.dp)
                        )
                        Text(
                            modifier = Modifier
                                .padding(horizontal = 16.dp)
                                .padding(bottom = 16.dp),
                            text = "by ${
                                if (item.name?.isNotEmpty() == true) item.name 
                                else stringResource(R.string.guest_text)
                            }"
                        )
                    }
                }
            }
        )

    }
}
