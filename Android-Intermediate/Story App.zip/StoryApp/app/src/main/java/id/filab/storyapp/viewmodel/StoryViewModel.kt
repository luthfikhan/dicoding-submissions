package id.filab.storyapp.viewmodel

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import id.filab.storyapp.R
import id.filab.storyapp.dto.StoryResponse
import id.filab.storyapp.dto.UploadStoryResponse
import id.filab.storyapp.services.getApiService
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class StoryViewModel: ViewModel() {
    var stories by mutableStateOf(StoryResponse())


    fun someThingWentWrong (context: Context, callback: (success: Boolean) -> Unit) {
        Toast.makeText(context, context.getString(R.string.something_went_wrong), Toast.LENGTH_LONG).show()
        stories = StoryResponse()
        callback(false)
    }

    fun getStories(token: String, context: Context, callback: (success: Boolean) -> Unit) {
        val api = getApiService().getAllStories("Bearer $token")

        api.enqueue(object: Callback<StoryResponse> {
            override fun onResponse(call: Call<StoryResponse>, response: Response<StoryResponse>) {
                if (response.isSuccessful) {
                    val body = response.body()

                    if (body?.error == false) {
                        stories = body
                        callback(true)
                    } else {
                        someThingWentWrong(context, callback)
                    }
                } else {
                    someThingWentWrong(context, callback)
                }
            }

            override fun onFailure(call: Call<StoryResponse>, t: Throwable) {
                someThingWentWrong(context, callback)
            }
        })
    }

    fun uploadStory(token: String, context: Context, imageFile: File, desc: String, callback: (success: Boolean) -> Unit) {
        val api = getApiService().uploadStory(
            "Bearer $token",
            MultipartBody.Part.createFormData(
                name = "photo",
                filename = imageFile.name,
                imageFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
            ),
            description = desc.toRequestBody("text/plain".toMediaType())
        )

        api.enqueue(object: Callback<UploadStoryResponse> {
            override fun onResponse(call: Call<UploadStoryResponse>, response: Response<UploadStoryResponse>) {
                if (response.isSuccessful) {
                    val body = response.body()

                    if (body?.error == false) {
                        callback(true)
                    } else {
                        someThingWentWrong(context, callback)
                    }
                } else {
                    someThingWentWrong(context, callback)
                }
            }

            override fun onFailure(call: Call<UploadStoryResponse>, t: Throwable) {
                someThingWentWrong(context, callback)
            }
        })
    }
}