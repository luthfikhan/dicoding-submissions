package id.filab.wisataskh.model

data class WisataSkhModel(
    val id: Int,
    val title: String,
    val description: String,
    val image: String
)
