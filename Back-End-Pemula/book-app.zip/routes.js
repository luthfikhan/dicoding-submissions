import book from './src/api/book.js';

const routes = [...book];

export default routes;
